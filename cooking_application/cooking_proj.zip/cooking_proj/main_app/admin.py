from django.contrib import admin
from main_app.models import Category, Dish


admin.site.register(Category)
admin.site.register(Dish)
